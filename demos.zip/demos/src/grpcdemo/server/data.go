package main

import (

	"grpcdemo/pb"
)

var employees = []pb.Employee {
	pb.Employee {
		Id: 1,
		EmployeeID: 1,
		FirstName: "Nikhil",
		LastName: "Sharma",
		Age: 60,
		Salary: 100,
	},
	pb.Employee {
		Id: 2,
		EmployeeID: 2,
		FirstName: "Tanya",
		LastName: "Shanker",
		Age: 		23,
		Salary: 23800,
	},
	pb.Employee {
		Id: 3,
		EmployeeID: 3,
		FirstName: "Saifi",
		LastName: "Saifi",
		Age: 12,
		Salary: 3000,
	},
}